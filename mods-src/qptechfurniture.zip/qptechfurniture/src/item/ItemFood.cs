﻿using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;

namespace QptechFurniture.src
{
    public class ItemFood : Item
    {
    }
}
