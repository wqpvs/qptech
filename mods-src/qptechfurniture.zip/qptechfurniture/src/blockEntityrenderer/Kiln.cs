﻿using System.Linq;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace QptechFurniture.src
{
    public class KilnContentsRenderer : IRenderer
    {
        MeshRef meshref;
        ICoreClientAPI api;
        BlockPos pos;
        public ItemStack ContentStack;
        Matrixf ModelMat = new Matrixf();

        ModelTransform transform;
        ModelTransform defaultTransform;

        public IInKilnRenderer contentStackRenderer;

        public double RenderOrder
        {
            get { return 0.5; }
        }

        public int RenderRange
        {
            get { return 48; }
        }

        public KilnContentsRenderer(ICoreClientAPI api, BlockPos pos)
        {
            this.api = api;
            this.pos = pos;
            transform = new ModelTransform().EnsureDefaultValues();
            transform.Origin.X = 8 / 16f;
            transform.Origin.Y = 1 / 16f;
            transform.Origin.Z = 8 / 16f;
            transform.Rotation.X = 90;
            transform.Rotation.Y = 90;
            transform.Rotation.Z = 0;
            transform.Translation.X = 0 / 32f;
            transform.Translation.Y = 4f / 16f;
            transform.Translation.Z = 0 / 32f;
            transform.ScaleXYZ.X = 0.25f;
            transform.ScaleXYZ.Y = 0.25f;
            transform.ScaleXYZ.Z = 0.25f;

            defaultTransform = transform;

        }


        internal void SetChildRenderer(ItemStack contentStack, IInKilnRenderer renderer)
        {
            this.ContentStack = contentStack;
            meshref?.Dispose();
            meshref = null;

            contentStackRenderer = renderer;
        }

        public void SetContents(ItemStack newContentStack, ModelTransform transform)
        {
            contentStackRenderer?.Dispose();
            contentStackRenderer = null;

            this.transform = transform;
            if (transform == null) this.transform = defaultTransform;
            this.transform.EnsureDefaultValues();

            meshref?.Dispose();
            meshref = null;

            if (newContentStack == null || newContentStack.Class == EnumItemClass.Block)
            {
                this.ContentStack = null;
                return;
            }

            if (newContentStack == null || newContentStack.Class == EnumItemClass.Item)
            {
                this.ContentStack = null;
                return;
            }
            this.ContentStack = newContentStack;
        }

        public void OnRenderFrame(float deltaTime, EnumRenderStage stage)
        {
            if (contentStackRenderer != null)
            {
                contentStackRenderer.OnRenderFrame(deltaTime, stage);
                return;
            }

            if (meshref == null) return;

            IRenderAPI rpi = api.Render;
            Vec3d camPos = api.World.Player.Entity.CameraPos;

            rpi.GlDisableCullFace();
            rpi.GlToggleBlend(true);

            IStandardShaderProgram prog = rpi.StandardShader;
            prog.Use();
            prog.Tex2D = api.ItemTextureAtlas.AtlasTextureIds[0];
            prog.DontWarpVertices = 0;
            prog.AddRenderFlags = 0;
            prog.RgbaAmbientIn = rpi.AmbientColor;
            prog.RgbaFogIn = rpi.FogColor;
            prog.FogMinIn = rpi.FogMin;
            prog.FogDensityIn = rpi.FogDensity;
            prog.RgbaTint = ColorUtil.WhiteArgbVec;
            prog.NormalShaded = 1;
            prog.ExtraGodray = 0;
            prog.SsaoAttn = 0;
            prog.AlphaTest = 0.05f;
            prog.OverlayOpacity = 0;

            int temp = (int)ContentStack.Collectible.GetTemperature(api.World, ContentStack);
            Vec4f lightrgbs = api.World.BlockAccessor.GetLightRGBs(pos.X, pos.Y, pos.Z);
            float[] glowColor = ColorUtil.GetIncandescenceColorAsColor4f(temp);
            lightrgbs[0] += glowColor[0];
            lightrgbs[1] += glowColor[1];
            lightrgbs[2] += glowColor[2];

            prog.RgbaLightIn = lightrgbs;

            prog.ExtraGlow = (int)GameMath.Clamp((temp - 400) / 80, 0, 255);


            prog.ModelMatrix = ModelMat
                .Identity()
                .Translate(pos.X - camPos.X + transform.Translation.X, pos.Y - camPos.Y + transform.Translation.Y, pos.Z - camPos.Z + transform.Translation.Z)
                .Translate(transform.Origin.X, 0.12f + transform.Origin.Y, transform.Origin.Z)
                .RotateX((90 + transform.Rotation.X) * GameMath.DEG2RAD)
                .RotateY(transform.Rotation.Y * GameMath.DEG2RAD)
                .RotateZ(transform.Rotation.Z * GameMath.DEG2RAD)
                .Scale(transform.ScaleXYZ.X, transform.ScaleXYZ.Y, transform.ScaleXYZ.Z)
                .Translate(-transform.Origin.X, -transform.Origin.Y, -transform.Origin.Z)
                .Values
            ;

            prog.ViewMatrix = rpi.CameraMatrixOriginf;
            prog.ProjectionMatrix = rpi.CurrentProjectionMatrix;

            rpi.RenderMesh(meshref);

            prog.Stop();
        }

        public void Dispose()
        {
            api.Event.UnregisterRenderer(this, EnumRenderStage.Opaque);

            meshref?.Dispose();
            contentStackRenderer?.Dispose();
        }

    }
}